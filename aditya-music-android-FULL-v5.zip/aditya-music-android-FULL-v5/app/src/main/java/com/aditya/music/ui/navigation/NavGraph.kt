package com.aditya.music.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.*
import com.aditya.music.ui.components.ConnectedMiniPlayer
import com.aditya.music.ui.screens.*
import com.aditya.music.ui.viewmodel.MusicViewModel

data class BottomNavItem(val screen: Screen, val icon: ImageVector, val label: String)

@Composable
fun AdityaNavGraph(
    viewModel: MusicViewModel,
    onRequestPermission: () -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val hasActiveSong by viewModel.currentSong.collectAsState()
    var miniPlayerVisible by remember { mutableStateOf(false) }

    LaunchedEffect(currentRoute, hasActiveSong != null) {
        if (currentRoute == Screen.NowPlaying.route || hasActiveSong == null) {
            miniPlayerVisible = false
        } else {
            // Let the Now Playing destination finish leaving before the Mini Player enters.
            delay(260L)
            miniPlayerVisible = true
        }
    }

    LaunchedEffect(navController) {
        viewModel.openNowPlayingEvents.collect {
            if (navController.currentDestination?.route != Screen.NowPlaying.route) {
                navController.navigate(Screen.NowPlaying.route) { launchSingleTop = true }
            }
        }
    }

    val navItems = listOf(
        BottomNavItem(Screen.Home, Icons.Rounded.Home, "Home"),
        BottomNavItem(Screen.Artists, Icons.Rounded.Person, "Artists"),
        BottomNavItem(Screen.Playlists, Icons.Rounded.QueueMusic, "Playlists")
    )

    Scaffold(
        bottomBar = {
            if (currentRoute != Screen.NowPlaying.route) {
                NavigationBar {
                    navItems.forEach { item ->
                        NavigationBarItem(
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            selected = currentRoute == item.screen.route,
                            onClick = {
                                if (item.screen == Screen.Home) {
                                    // Home is a true root destination: one tap from any nested page
                                    // returns directly to the Home music area.
                                    if (navController.currentDestination?.route != Screen.Home.route) {
                                        val popped = navController.popBackStack(Screen.Home.route, false)
                                        if (!popped && navController.currentDestination?.route != Screen.Home.route) {
                                            navController.navigate(Screen.Home.route) {
                                                launchSingleTop = true
                                            }
                                        }
                                    }
                                } else {
                                    navController.navigate(item.screen.route) {
                                        popUpTo(Screen.Home.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }
                composable(Screen.Songs.route) {
                    SongsScreen(viewModel = viewModel)
                }
                composable(Screen.Albums.route) {
                    AlbumsScreen(
                        viewModel = viewModel,
                        onAlbumClick = { albumId -> navController.navigate(Screen.AlbumDetail.createRoute(albumId)) }
                    )
                }
                composable(Screen.Artists.route) {
                    ArtistsScreen(
                        viewModel = viewModel,
                        onArtistClick = { artistId -> navController.navigate(Screen.ArtistDetail.createRoute(artistId)) }
                    )
                }
                composable(Screen.Playlists.route) {
                    PlaylistsScreen(viewModel = viewModel)
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Screen.NowPlaying.route) {
                    NowPlayingScreen(
                        viewModel = viewModel,
                        onClose = { navController.popBackStack() },
                        onOpenQueue = { navController.navigate(Screen.Queue.route) }
                    )
                }
                composable(Screen.Queue.route) {
                    QueueScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }

            // Keep MiniPlayer's fast-changing playback state isolated from the NavHost.
            // This prevents a position tick from recomposing the whole Home screen while scrolling.
            Box(modifier = Modifier.align(Alignment.BottomCenter)) {
                AnimatedVisibility(
                    visible = miniPlayerVisible && currentRoute != Screen.NowPlaying.route,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    ConnectedMiniPlayer(
                        viewModel = viewModel,
                        visible = true,
                        onClick = { navController.navigate(Screen.NowPlaying.route) { launchSingleTop = true } },
                        onDismiss = viewModel::dismissPlayer
                    )
                }
            }
        }
    }
}
